let displayValue = '';
let currentOperator = '';
let firstOperand = '';

function handleButtonClick(event) {
    const buttonValue = event.target.textContent;

    if (!isNaN(buttonValue) || buttonValue === '.') {
        // If the button is a number or a dot
        displayValue += buttonValue;
    } else if (buttonValue === '+' || buttonValue === '-' || buttonValue === '*' || buttonValue === '/') {
        // If the button is an operator
        if (currentOperator !== '') {
            // If there is already an operator, perform the previous operation
            performCalculation();
        }
        currentOperator = buttonValue;
        firstOperand = displayValue;
        displayValue = '';
    } else if (buttonValue === '=') {
        // If the button is the equals sign
        performCalculation();
    } else if (buttonValue === 'C') {
        // If the button is the clear button
        clearDisplay();
    }

    updateDisplay();
}

function performCalculation() {
    const operand1 = parseFloat(firstOperand);
    const operand2 = parseFloat(displayValue);

    if (!isNaN(operand1) && !isNaN(operand2)) {
        switch (currentOperator) {
            case '+':
                displayValue = (operand1 + operand2).toString();
                break;
            case '-':
                displayValue = (operand1 - operand2).toString();
                break;
            case '*':
                displayValue = (operand1 * operand2).toString();
                break;
            case '/':
                if (operand2 !== 0) {
                    displayValue = (operand1 / operand2).toString();
                } else {
                    displayValue = 'Error';
                }
                break;
        }

        currentOperator = '';
        firstOperand = '';
    }
}

function updateDisplay() {
    document.getElementById('display').value = displayValue;
}

function clearDisplay() {
    displayValue = '';
    currentOperator = '';
    firstOperand = '';
    updateDisplay();
}